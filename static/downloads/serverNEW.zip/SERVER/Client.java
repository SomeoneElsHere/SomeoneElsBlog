import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class Client extends Thread
{


Socket cli;
static InputStream inCLI;
static OutputStream out;

Scanner SENDER = new Scanner(System.in);
byte SEND;
String MESSAGE;


  public Client()
  {
  SETUP();
  ClientSide();
  }
  
  
  
  
  public void SETUP()
  {
     //Create socket connection
   try
   {
     cli = new Socket("RANDO_D", 3030);
     out = this.cli.getOutputStream();
     inCLI = this.cli.getInputStream();
     
   } 
   catch  (IOException e) 
   {
     System.out.println("No I/O");
     System.exit(1);
   }
   
   //connection exists
   
   
 }
 
 
 
  
  
  public void ClientSide()
  {
  try
  {
  
  
  
  MESSAGE = SENDER.next();
  
  for(char BIT : MESSAGE.toCharArray())
  {
   SEND = (byte)BIT;
   this.out.write(SEND);
  }
  this.sleep(500);
  this.out.write(13);
  System.exit(0);
  
  
  
  
  }
  catch(Exception E)
  {
  }
  }
  
   public static void main(String[] args) throws IOException 
   {
   Client newCLIENT = new Client();
   }
  
  
    
}