import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class ClientRUN implements Runnable 
{

   public static Thread CLIENT;
   public static Client RUNCLIENT;
   public ClientRUN()
   {
   
   CLIENT = new Thread(this,"CLIENT");
   
   }
   
   public void run()
   {
   RUNCLIENT = new Client();
   }
   
   public static Thread getThread()
   {
   return CLIENT;
   
   }
   

}