import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class RUN extends Thread
{

   public static void main(String[] args) throws IOException 
   { 
   
   ClientRUN c = new ClientRUN();
   ServerRUN s = new ServerRUN();
   
   Thread SERVERTHREAD = s.getThread();
   Thread CLIENTTHREAD = c.getThread();
   SERVERTHREAD.start();
   CLIENTTHREAD.start();
   
   
   ClientRUN c2 = new ClientRUN();
   Thread CLIENTTHREAD2 = c2.getThread();
   CLIENTTHREAD2.start();
   
   }

}