import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;



public class Server extends Thread
{
ServerSocket sev;
Socket client;
InputStream Sin;
OutputStream Sout;
char BIT;

  public Server()
  {
  SETUP();
  ServerSide();
  
  }
  
  public void ServerSide()
  {
  try
  {
  while(true)
  {
  //loop start
  
  while(!FINDSOCKET())
  {
  }
  
  
  
  while( BIT != 13)
  {
  
  System.out.print(BIT);
  BIT = (char)Sin.read();
  }
  client.close();
  BIT=0;
  System.out.println();
  
  
    
  //loop end
  }
  }
  catch(Exception E)
  {
  }
  }

  
  
  
  
  
  
  
  
  
  
  
  
  private void SETUP()
  {
  try
  {
    sev = new ServerSocket(3030); 
  } 
  catch (IOException a) 
  {
    System.out.println("SEV.excep: Socket not available.\n");
    System.exit(-1);
  }
  }
  
  private boolean FINDSOCKET()
  {
  try
  {
    client = sev.accept(); 
    
    return CONNECTSOCKET();
    
  } 
  catch (IOException b) 
  {
    System.out.println("SEV.excep: Socket not available.\n");
    return false;
  }
  }
  
  
  
  private boolean CONNECTSOCKET()
  {
  try
  {
   Sin =  client.getInputStream();
   Sout = client.getOutputStream();
   return true;
  } 
  catch (IOException c) 
  {
    System.out.println("SetRead failed");
    return false;
  }
  }
  


   public static void main(String[] args) throws IOException 
   {
   Server sev = new Server();
   }


  }
  
