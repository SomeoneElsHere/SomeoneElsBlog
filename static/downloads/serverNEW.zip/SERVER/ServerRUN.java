import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class ServerRUN implements Runnable 
{
   public static Thread SERVER;
   public static Server RUNSERVER;
   
   public ServerRUN()
   {
   
   SERVER = new Thread(this,"SERVER");
   }
   
   public void run()
   {
   RUNSERVER = new Server();
   
   
   }
   
   public Thread getThread()
   {
   return SERVER;
   
   }
   
   
   

}